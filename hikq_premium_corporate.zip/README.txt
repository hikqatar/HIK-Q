
HIK Q Premium Corporate Static Site
----------------------------------
Files included:
- index.html
- assets/style.css
- assets/main.js
- assets/banner.jpg (placeholder)
- assets/logo-hikvision.svg, logo-ruijie.svg, logo-televes.svg (placeholders)
- images/*.jpg (project placeholders)

How to use:
1. Replace placeholder images in assets/ and images/ with real images (optimized web versions, e.g., webp/jpg).
2. Upload the folder contents to your hosting (public_html or site root).
3. Configure contact form (replace form action with Formspree, Netlify Form, or server endpoint).

Want this converted to a WordPress child theme or Elementor kit? Tell me and I'll prepare that next.
